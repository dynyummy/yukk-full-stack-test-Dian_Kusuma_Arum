
<?php $__env->startSection('container'); ?>
<main class="form-signin w-100 m-auto">
<form>
<img class="mb-4" src="../assets/brand/logo-yukk.png" alt="" width="280" height="57">
    <h1 class="h3 mb-3 fw-normal">Please register</h1>

  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <br>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
  <br>
 
  <button type="submit" class="btn btn-primary">Register</button>
</form>
<main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekku\resources\views/register.blade.php ENDPATH**/ ?>