
<?php $__env->startSection('container'); ?>


<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Riwayat Saldo User</h1>
<div class="row">
    <div class="col-md-12">
        <form action="/cari">
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Cari Kode Transaksi/ Keterangan" name="cari">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit" >Cari</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Riwayat Saldo</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive text-center">
            <table class="table table-bordered dataTables_wrapper" id="dataTables_wrapper" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Kode Transaksi</th>
                        <th>Tipe Transaksi</th>
                        <th>Amount</th>
                        <th>Keterangan</th>
                        <th>Current Ballance</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Kode Transaksi</th>
                        <th>Tipe Transaksi</th>
                        <th>Amount</th>
                        <th>Keterangan</th>
                        <th>Current Ballance</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $i = 1; ?><?php $__currentLoopData = $data_riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td class="text-center"><?php echo e($d->name); ?></td>
                        <td class="text-center"><?php echo e($d->id_transaksi); ?></td>
                        <td class="text-center"><?php echo e($d->nama_transaksi); ?></td>
                        <td class="text-center"><?php echo e($d->amount); ?></td>
                        <td class="text-center"><?php echo e($d->keterangan); ?></td>
                        <td class="text-center"><?php echo e($d->saldo); ?></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="d-flex justify-content-center"
<?php echo e($data_riwayat->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekku\resources\views/riwayat_saldo/index.blade.php ENDPATH**/ ?>