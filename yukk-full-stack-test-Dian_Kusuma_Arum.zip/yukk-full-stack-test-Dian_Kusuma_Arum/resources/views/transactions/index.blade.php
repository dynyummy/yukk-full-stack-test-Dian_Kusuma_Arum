@extends('layouts/admin')
@section('container')

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Data Transaksi</h1>
<a href="/create" class="btn btn-primary mb-4 mt-4" type="button">
    <i class="fas fa-archive fa-sm"></i> Tambah Data
</a>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tabel Transaksi</h6>
    </div>
    <div class="card-body">
    @if(session()->has('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
    </div>
    @endif
    <br>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th class="text-center">Kode Transaksi</th>
                        <th class="text-center">Tipe Transaksi</th>
                        <th class="text-center">Amount</th>
                        <th class="text-center">Keterangan</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th class="text-center">No</th>
                        <th class="text-center">Kode Transaksi</th>
                        <th class="text-center">Tipe Transaksi</th>
                        <th class="text-center">Amount</th>
                        <th class="text-center">Keterangan</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $i = 1; ?>@foreach($data_transaksi as $d)
                    <tr>
                        <td class="text-center">{{$loop->iteration}}</td>
                        <td class="text-center">{{$d->id_transaksi}}</td>
                        <td class="text-center">{{$d->nama_transaksi}}</td>
                        <td class="text-center">{{$d->amount}}</td>
                        <td class="text-center">{{$d->keterangan}}</td>
                        <td class="text-center">
                        <!-- <a href="/show/{{$d->id_transaksi}}" class="btn btn-md btn-secondary" id="btPreview" ><i class="fas fa-eye"></i></a> -->
                            <a href="/{{$d->id_transaksi}}" class="btn btn-md btn-info"><i class="fas fa-pen"></i></a>
                            <form action="{{route('transaksi.delete', ['id' => $d->id_transaksi])}}" method="post" class="d-inline">
                                @method('delete')
                                @csrf
                                <button class="btn btn-md btn-danger " onclick="return confirm('Yakin Dihapus?');"><i class="fas fa-trash"></i></button>
                            </form>
                            
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="d-flex justify-content-center"
{{ $data_transaksi->links() }}
</div>
@endsection

