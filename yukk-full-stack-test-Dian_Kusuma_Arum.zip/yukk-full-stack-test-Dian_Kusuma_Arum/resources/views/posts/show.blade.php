@extends('/layouts/admin')
@section('container')
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">

            <div class="col-lg-10 text-justify">
                <div class="p-5">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Detail Transaksi</h1>
                    </div>
                    <form class="user" action="{{route('transaksi.show', ['id' => $post->id_transaksi])}}" method="post" enctype="multipart/form-data">
                        @method('put')
                        @csrf
                        <input type="hidden" name="id_user" value="{{ auth()->user()->id }}">
                        <div class="form-group">
                            <label for="jenis" class="form-label">Pilih Jenis Transaksi{{$post->id_transaksi}}</label>
                            <select class="form-control" name="nama_transaksi" disabled>
                                <option value="Top Up" {{ $post->nama_transaksi == "Top Up" ? 'selected' : '' }}>Top Up</option>
                                <option value="Transfer" {{ $post->nama_transaksi == "Transfer" ? 'selected' : '' }}>Transfer</option>
                            </select>
                            @error('nama_transaksi')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>

                        
                        <div class="form-group">
                            <label for="amout" class="form-label">Amount</label>
                                <input type="text" name="amount" id="amount" class="form-control @error('amount') is-invalid @enderror" placeholder="Amount" required value="{{old('amount',$post->amount)}}" disabled>
                                @error('amount')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>
                            <div class="form-group">
                            <label for="jenis" class="form-label">Bukti Bayar</label><br>
                            <img class="btn p-0 card-img1" src="/storage/{{$post->bukti_bayar}}" width="200px">
                            </div>
                        
                        <div class="form-group">
                        <label for="jenis" class="form-label">Keterangan</label><br>
                            <input type="text" class="form-control  @error('keterangan') is-invalid @enderror" name="keterangan" id="keterangan" placeholder="Keterangan" required value="{{old('keterangan',$post->keterangan)}}" disabled>
                            @error('keterangan')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>

                        <a href="/transactions" class="btn btn-secondary btn-user " onclick="history.back()"> Kembali
                        </a>

                    </form>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection