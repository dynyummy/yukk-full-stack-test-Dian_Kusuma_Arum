@extends('layouts/admin')
@section('container')
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">

            <div class="col-lg-12">
                <div class="p-5">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Tambah Transaksi</h1>
                    </div>
                    <form class="user" action="/store" method="post" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="id_user" value="{{ auth()->user()->id }}">
                        <div class="form-group">
                            <label for="jenis" class="form-label">Pilih Jenis Transaksi</label>
                            <input class="form-control @error('nama_transaksi') is-invalid @enderror" list="nama_transaksi" name="nama_transaksi" id="browser" value="{{old('nama_transaksi')}}">
                            <datalist id="nama_transaksi">
                                <option value="Top Up">
                                <option value="Transfer">
                            </datalist>
                            @error('nama_transaksi')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <input type="text" name="amount" id="amount" class="form-control @error('amount') is-invalid @enderror" placeholder="Amount" required value="{{old('amount')}}">
                                @error('amount')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>
                            <div class="col-sm-6">
                                <input type="file" class="form-control @error('bukti_bayar') is-invalid @enderror" name="bukti_bayar" id="bukti_bayar" placeholder="Bukti Bayar" value="{{old('bukti_bayar')}}">
                                @error('bukti_bayar')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control  @error('keterangan') is-invalid @enderror" name="keterangan" id="keterangan" placeholder="Keterangan" required value="{{old('keterangan')}}">
                            @error('keterangan')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary btn-user btn-block">
                            <i class="fab fa-archive fa-fw"></i> Simpan
                        </button>
                        <a href="/transactions" class="btn btn-secondary btn-user btn-block">
                            <i class="fab fa-archive fa-fw"></i> Cancel
                        </a>

                    </form>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection