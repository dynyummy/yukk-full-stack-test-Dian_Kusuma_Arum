@extends('layouts/main')
@section('container')
<main class="form-signin w-100 m-auto">
<form action="/register" method="post">
<img class="mb-4" src="../assets/brand/logo-yukk.png" alt="" width="280" height="57">
    <h1 class="h3 mb-3 fw-normal">Please register</h1>
@csrf
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" id="name" aria-describedby="nameHelp" placeholder="Name" required value="{{old('name')}}">
    @error('name')
    <div class="invalid-feedback">
        {{ $message }}
    </div>
    @enderror
</div>
  <br>
  
    <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control @error('email') is-invalid @enderror" name="email" id="email" aria-describedby="emailHelp" placeholder="Enter email" required value="{{old('email')}}">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    @error('email')
    <div class="invalid-feedback">
        {{ $message }}
    </div>
    @enderror
</div>
  <br>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control @error('password') is-invalid @enderror" name="password" id="password" placeholder="Password" required>
    @error('password')
    <div class="invalid-feedback">
        {{ $message }}
    </div>
    @enderror
</div>
  <br>
 
  <button type="submit" class="btn btn-primary">Register</button>
</form>
<main>
@endsection