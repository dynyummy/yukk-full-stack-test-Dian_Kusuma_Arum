<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PostModel;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class PostsController extends Controller
{
    public function index()
    {
        $data = DB::table('transactions')->get();

        //return view('transactions.index', ['data_transaksi' => $data]);
        return view('transactions.index', ['data_transaksi' => $data, 'title' => 'Data Transaksi']);
    }
    public function create()
    {

        return view('posts.create', ['title' => 'Tambah Transaksi']);
    }

    public function store(Request $request)
    {

        $validateData = $request->validate([
            'nama_transaksi'     => 'required',
            'amount'             => 'required',
            'bukti_bayar'        => 'image|file|max:1024',
            'keterangan'         => 'required',
        ]);
        if ($request->file('bukti_bayar')) {
            $validateData['bukti_bayar'] = $request->file('bukti_bayar')->store('post-images');
        }
        $validateData['id_user'] = Auth::id();
        //dd($validateData);
        PostModel::create($validateData);
        return redirect('/transactions')->with('success', 'Data Berhasil Tersimpan');
    }


    public function delete($id)
    {
        $del = PostModel::find($id);
        $del->delete(); 
        return redirect('/transactions')->with('success', 'Data Berhasil Dihapus');
    }
    public function edit($id)
    {
        return view('posts.edit', [
            'title' => 'Edit Transaksi',
            'post'  => PostModel::find($id),
            'datas' => PostModel::All()
    ]);
  
    }
    

    public function update(Request $request, $id)
    {
        $data = PostModel::find($id);
        $data->nama_transaksi = $request->input('nama_transaksi');
        $data->amount = $request->input('amount');
        $data->keterangan = $request->input('keterangan');
        if ($request->file('bukti_bayar')) {
            $data->bukti_bayar = $request->file('bukti_bayar')->store('post-images');
        }
        $data->update();
        return redirect('/transactions')->with('success', 'Data Berhasil Diupdate');
    }
    public function show($id)
    {
        return view('posts.show', [
            'title' => 'Detail Transaksi',
            'post'  => PostModel::find($id),
            'datas' => PostModel::All()
    ]);
  
    }

}
