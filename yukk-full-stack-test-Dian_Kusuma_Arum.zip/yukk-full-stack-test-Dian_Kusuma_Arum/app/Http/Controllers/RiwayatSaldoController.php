<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class RiwayatSaldoController extends Controller
{
    public function index()
    {
        //$data = DB::table('riawayat_saldo')->get();
        $id=Auth::id();
        $data = DB::table('riawayat_saldo')
            ->select('*')
            ->join('users', 'riawayat_saldo.id_user', '=', 'users.id')
            ->join('transactions', 'riawayat_saldo.id_transaksi', '=', 'transactions.id_transaksi')
            ->where('riawayat_saldo.id_user',$id)
            ->paginate(5);

        //return view('transactions.index', ['data_transaksi' => $data]);
        return view('riwayat_saldo.index', ['data_riwayat' => $data, 'title' => 'Riwayat Saldo']);
    }
    public function cari()
    {
       
        if(request('cari')){
            $data = DB::table('riawayat_saldo')
            ->select('*')
            ->join('users', 'riawayat_saldo.id_user', '=', 'users.id')
            ->join('transactions', 'riawayat_saldo.id_transaksi', '=', 'transactions.id_transaksi')
            ->where('transactions.id_transaksi','like', '%'.request('cari').'%')
            ->orWhere('transactions.keterangan','like', '%'.request('cari').'%')
            ->paginate(5);
            
        }else{
            $data = DB::table('riawayat_saldo')
            ->select('*')
            ->join('users', 'riawayat_saldo.id_user', '=', 'users.id')
            ->join('transactions', 'riawayat_saldo.id_transaksi', '=', 'transactions.id_transaksi')
            ->paginate(5);
        }
       
//dd($data);
        return view('riwayat_saldo.index', ['data_riwayat' => $data, 'title' => 'Riwayat Saldo']);
    }


}
