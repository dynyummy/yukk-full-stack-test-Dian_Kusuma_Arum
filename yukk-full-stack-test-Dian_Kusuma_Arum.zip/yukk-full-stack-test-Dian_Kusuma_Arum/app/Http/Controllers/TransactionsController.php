<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class TransactionsController extends Controller
{
    public function index(){
        $id=Auth::id();
        $data = DB::table('transactions')->where('id_user',$id)->paginate(5);
        
        //return view('transactions.index', ['data_transaksi' => $data]);
        return view('transactions.index',['data_transaksi' => $data,'title' => 'Data Transaksi']);
    }
    // public function create(){
    //     return view('create.index',['title' => 'Tambah Data Transaksi']);
    // }
}
